<?php
session_start();
$_SESSION;

include("connection.php");
include("functions.php");

$user_data = check_login($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elansol Assignment</title>
    <script src="https://kit.fontawesome.com/5e33d24f13.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <?php include ('dashboard.php'); ?>
</body>
</html>
