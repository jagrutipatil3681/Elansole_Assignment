<!-- navbar.php  -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/login.css">
    <script src="https://kit.fontawesome.com/5e33d24f13.js" crossorigin="anonymous"></script>
</head>
<body>
<div class="dashboard_topnav">
        <a href="dashboard.php" id="togglebtn"><i class="fa-solid fa-bars"></i></a>
        
        <a href="index.php" class="btn btn-danger float-right">Back</a>

        <a href="logout.php" id="logoutbtn"><i class="fa-solid fa-right-from-bracket"></i>Log out</a>
            


    
</body>
</html>