<?php 
session_start();
include("connection.php");
include("functions.php");

if($_SERVER ["REQUEST_METHOD"] == "POST")
{
    // something was posted 
    $user_name = $_POST['user_name'];
    $password = $_POST['password'];

    if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
    {
        // read from database 
        $query = "select * from users where user_name = '$user_name' limit 1";   
        $result = mysqli_query ($con,$query);
if($result)
        {
            if($result &&  mysqli_num_rows ($result) > 0)
                {
                    $user_data = mysqli_fetch_assoc($result);
                    if($user_data['password'] === $password)
                    {
                        $_SESSION['user_id'] = $user_data['user_id'];
                        header("Location:index.php");
                        die;
                    }
                }
        }
        echo "Wrong username and password!";
}  else 
    {
        echo "Please enter some valid information!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        div {
            background-color: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        div div {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        input {
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            width: 100%;
        }

        input[type="submit"] {
            background-color: #2a2f2b;
            color: #fff;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #bcc1bd;
        }

        a {
            text-decoration: none;
            color: #333;
            margin-top: 10px;
            display: inline-block;
        }
    </style>
<body>
    <div>
        <form method="post">
           <div>Login</div>
            <input type="text" name="user_name" placeholder="Username"><br>
            <input type="password" name="password" placeholder="Password"><br>

            <input type="submit" value="Login"><br>
            <a href="signup.php">Register</a>
        </form>
    </div>
</body>
</html>