<!-- sidebar.php  -->
<?php
session_start();
$_SESSION;

include("connection.php");
include("functions.php");

$user_data = check_login($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/login.css">
    <script src="https://kit.fontawesome.com/5e33d24f13.js" crossorigin="anonymous"></script>
</head>
<body>
<div class="dashboard_sidebar" id="dashboard_sidebar" >
            <h3 class="dashboard_logo" id="dashboard_logo"></h3> 
            <div class="dashboard_sidebar_user">
            </div>
            
        </div>
  
</body>
</html>