<? $user_data = check_login($con);   ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/login.css">
    <script src="https://kit.fontawesome.com/5e33d24f13.js" crossorigin="anonymous"></script>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        button {
            cursor: pointer;
            padding: 5px 10px;
            margin: 5px;
            background-color: #888b88;
            color: #fff;
            border: none;
            border-radius: 3px;
        }

        .dashboard_sidebar_user{
                padding-top: 50px;
        }
    </style>
</head>

<body>
    <div id="dashboardMainContainer" class="container">
        <div class="dashboard_sidebar" id="dashboard_sidebar">
           
            <div class="dashboard_sidebar_user">
                <img src="images/user.webp" alt="userimage." id="userImage" />
                <span><?php echo $user_data["user_name"]; ?></span>
            </div>

        </div>
        <div class="dashboard_content_container" id="dashboard_content_container">
            <div class="dashboard_topnav">

                <a href="logout.php" id="logoutbtn"><i class="fa-solid fa-right-from-bracket"></i>Log out</a>
            </div>
            <div class="dashboard_content">
                <div class="dashboard_content_main">
                    <?php
                    $dbhost = "localhost";
                    $dbuser = "root";
                    $dbpass = "";
                    $dbname = "ems";
                    $con = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

                    if ($con->connect_error) {
                        die("FAILED TO CONNECT: " . $con->connect_error);
                    }

                    $searchTerm = isset($_GET['search']) ? $_GET['search'] : '';

                    $query = "SELECT * FROM employees WHERE id  LIKE '%$searchTerm%' OR employee_name LIKE '%$searchTerm%'";
                    $result = $con->query($query);
                    $con->close();
                    ?>

                    <table border>
                        <tr>
                            <th>Name</th>
                            <th>Date</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>


                    </table>
                </div>
            </div>
        </div>
    </div>

</body>

</html>