<?php 
session_start();
include("connection.php");
include("functions.php");

if($_SERVER ["REQUEST_METHOD"] == "POST")
{
    // something was posted 
    $user_name = $_POST['user_name'];
    $password = $_POST['password'];

    if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
    {
        // save to database 
        $user_id = random_num(20);
        $query = "INSERT INTO `users`(`id`, `user_id`, `user_name`, `password`, `date`) VALUES ('[value-1]','$user_id','$user_name','$password','[value-5]')";   
        mysqli_query ($con,$query);

        header("Location:login.php");
        die;
}  else 
    {
        echo "Please enter some valid information!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Page</title>
</head>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        div {
            background-color: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        div div {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        input {
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            width: 100%;
        }

        input[type="submit"] {
            background-color: #2a2f2b;
            color: #fff;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #bcc1bd;
        }

        a {
            text-decoration: none;
            color: #333;
            margin-top: 10px;
            display: inline-block;
        }
    </style>
<body>
    <div>
        <form method="post">
            <div>Signup</div>
            <input type="text" name="user_name" placeholder="Username"><br>
            <input type="date" name="doj" placeholder="Date Of Birth"><br>
            <input type="text" name="email" placeholder="Email"><br>
            <input type="password" name="password" placeholder="Password"><br>

            <input type="submit" value="Signup"><br>
            <a href="login.php">Click to Login</a>
        </form>
    </div>
</body>
</html>