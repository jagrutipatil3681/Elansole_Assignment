<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "ems";

if(!$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname))
{
    die("FAILED TO CONNECT.");
}
echo "";